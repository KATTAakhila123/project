const bar=document.getElementById('bar');
const nav=document.getElementById('navbar');

if(bar){
	bar.addEventListner('click',()=>
	{
		nav.classList.add('active');
	})
}
if(close){
	close.addEventListner('click',()=>
	{
		nav.classList.remove('active');
	})
}